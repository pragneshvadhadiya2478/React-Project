import images from "./homeimg.jpg"
function Home() {
    return (
        <>
           <div >
            <div className>
            <img src={images} class="img-fluid" alt="..." className="homeimg"/>
            </div>
            <br/>
            <div className="container my-3">

            <p class="text-start">Umiya Mobile Private Limited is a Private incorporated on 31 December 2012. It is classified as Non-govt company and is registered at Registrar of Companies, Ahmedabad. Its authorized share capital is Rs. 6,500,000 and its paid up capital is Rs. 5,500,000. It is inolved in Manufacture of television and radio transmitters and apparatus for line telephony and line telegraphy</p>
<p class="text-start">Umiya Mobile Private Limited's Annual General Meeting (AGM) was last held on 29 November 2021 and as per records from Ministry of Corporate Affairs (MCA), its balance sheet was last filed on 31 March 2021.
</p>
<p class="text-start">Directors of Umiya Mobile Private Limited are Girishkumar Premjibhai Jadvani, Vijesh Premjibhai Patel and Kishorbhai Premjibhai Jadwani.</p>

<p class="text-start">Umiya Mobile Private Limited's Corporate Identification Number is (CIN) U32202GJ2012PTC073173 and its registration number is 73173.Its Email address is umiyacellularpoint@gmail.com and its registered address is PLOT NO.3, WARD NO.7, C.S. NO.5805, VHORA AGHAT NR PDM COM.COLLAGE,OPP.LATHIYA MOTORS,GONDAL ROAD RAJKOT GJ 360004 IN , - , .</p>
<p class="text-start">Update Information</p>
<p class="text-start">
We are adding and updating information about hundreds of thousands of companies every day, and periodically add companies to the queue for being updated. You can ask for a company to be added to the front of the queue for updating, especially useful if the address, directors, or other critical information has changed. Just click on the 'Update Information' button below to start the process.</p>
<p class="text-start">Start aligned text on viewports sized XL (extra-large) or wider.</p>

            </div>
            </div>
        </>
    )
}
export default Home;