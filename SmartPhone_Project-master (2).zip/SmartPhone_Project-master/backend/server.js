const express = require('express');
const cors = require('cors');
const { v4: uuidv4 } = require('uuid'); // For generating unique IDs

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// In-memory smartphone storage
let smartphones = [
    {
        SmartPhoneId: "1",
        SmartPhoneName: "iPhone 15 Pro",
        SmartPhoneModel: "A2901",
        SmartPhoneMaker: "Apple",
        SmartPhoneDescription: "The latest iPhone with advanced features.",
        SmartPhonePrice: 999,
        SmartPhoneImage: "https://example.com/iphone15pro.jpg"
    },
    // Add more smartphones if needed
];

// Routes
// Get all smartphones
app.get('/smartphones', (req, res) => {
    res.json(smartphones);
});

// Get smartphone by ID
app.get('/smartphones/:id', (req, res) => {
    const smartphone = smartphones.find(sp => sp.SmartPhoneId === req.params.id);
    if (!smartphone) {
        return res.status(404).json({ error: 'Smartphone not found' });
    }
    res.json(smartphone);
});

// Create a new smartphone
app.post('/smartphones', (req, res) => {
    const newSmartphone = {
        ...req.body,
        SmartPhoneId: uuidv4() // Generate a new unique ID
    };
    smartphones.push(newSmartphone);
    res.status(201).json(newSmartphone);
});

// Update smartphone by ID
app.put('/smartphones/:id', (req, res) => {
    const index = smartphones.findIndex(sp => sp.SmartPhoneId === req.params.id);
    if (index === -1) {
        return res.status(404).json({ error: 'Smartphone not found' });
    }
    smartphones[index] = { ...smartphones[index], ...req.body };
    res.json(smartphones[index]);
});

// Delete smartphone by ID
app.delete('/smartphones/:id', (req, res) => {
    const index = smartphones.findIndex(sp => sp.SmartPhoneId === req.params.id);
    if (index === -1) {
        return res.status(404).json({ error: 'Smartphone not found' });
    }
    smartphones.splice(index, 1);
    res.json({ message: 'Smartphone deleted successfully' });
});

// Start server
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
